const predictBtn = document.getElementById('predictBtn');
const clearBtn = document.getElementById('clearBtn');
const reviewInput = document.getElementById('reviewInput');
const resultCard = document.getElementById('resultCard');
const labelEl = document.getElementById('label');
const confidenceEl = document.getElementById('confidence');
const aspectsEl = document.getElementById('aspects');

function humanLabel(v) {
  return v === 1 ? 'Liked (Positive)' : 'Not Liked (Negative)';
}

function showResult(data) {
  resultCard.classList.remove('hidden');
  labelEl.textContent = humanLabel(data.prediction);
  confidenceEl.textContent = data.probability !== null ? (data.probability*100).toFixed(2)+'%' : 'N/A';
  aspectsEl.innerHTML = '';
  const aspects = data.aspects || {};
  if (Object.keys(aspects).length === 0) {
    aspectsEl.innerHTML = '<div class="aspect"><div class="sent">No aspect keywords found.</div></div>';
    return;
  }
  for (const [asp, arr] of Object.entries(aspects)) {
    const wrapper = document.createElement('div');
    wrapper.className = 'aspect';
    const title = document.createElement('div');
    title.innerHTML = `<strong>Aspect:</strong> ${asp}`;
    wrapper.appendChild(title);
    arr.forEach(item => {
      const p = document.createElement('div');
      p.className = 'sent';
      p.innerHTML = `${item.sentence} <br/><strong>Label:</strong> ${item.pred===1 ? 'Positive' : 'Negative'} ${item.probability !== null ? '(' + (item.probability*100).toFixed(1)+'%)' : ''}`;
      wrapper.appendChild(p);
    });
    aspectsEl.appendChild(wrapper);
  }
}

predictBtn.addEventListener('click', async () => {
  const text = reviewInput.value.trim();
  if (!text) return alert('Paste a review to classify.');
  predictBtn.disabled = true;
  predictBtn.textContent = 'Predicting...';
  try {
    const res = await fetch('/predict', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({text})
    });
    if (!res.ok) throw new Error('Server error: ' + res.status);
    const data = await res.json();
    showResult(data);
  } catch (err) {
    alert('Error: ' + err.message);
  } finally {
    predictBtn.disabled = false;
    predictBtn.textContent = 'Predict';
  }
});

clearBtn.addEventListener('click', () => {
  reviewInput.value = '';
  resultCard.classList.add('hidden');
});
