from flask import Flask, request, jsonify, send_from_directory
import pickle, re, nltk, os, traceback
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer

# -------------------------
# LOAD MODEL + VECTORIZER
# -------------------------
with open('model.pkl','rb') as f:
    model = pickle.load(f)

with open('vectorizer.pkl','rb') as f:
    tfv = pickle.load(f)

# -------------------------
# NLTK SETUP
# -------------------------
nltk.download('punkt')
nltk.download('stopwords')
try:
    nltk.download('punkt_tab')
except:
    pass

stop_words = set(stopwords.words('english'))
ps = PorterStemmer()

# -------------------------
# ASPECT KEYWORDS
# -------------------------
aspects_keywords = {
    'food': ['food','taste','flavor','dish','meal'],
    'service': ['service','staff','waiter','waitress','server'],
    'speed': ['quick','slow','speed','time','wait'],
    'hygiene': ['hygiene','clean','dirty','sanitary','unclean'],
    'ambience': ['ambience','ambiance','atmosphere','music','decor'],
    'price': ['price','cost','expensive','cheap','value']
}

# -------------------------
# FLASK APP
# -------------------------
app = Flask(__name__, static_folder='static', static_url_path='')

# -------------------------
# PREPROCESS FUNCTION
# -------------------------
def preprocess(text):
    text = re.sub('[^a-zA-Z]', ' ', str(text))
    tokens = nltk.word_tokenize(text.lower())
    tokens = [ps.stem(w) for w in tokens if w not in stop_words and len(w) > 1]
    return ' '.join(tokens)

# -------------------------
# ASPECT EXTRACTION
# -------------------------
def extract_aspects_using_model(text):
    sentences = nltk.sent_tokenize(text)
    found = {}
    for sent in sentences:
        sent_lower = sent.lower()
        for asp, kws in aspects_keywords.items():
            for kw in kws:
                if kw in sent_lower:
                    t = preprocess(sent)
                    v = tfv.transform([t]).toarray()
                    pred = int(model.predict(v)[0])
                    prob = float(model.predict_proba(v).max())
                    if asp not in found:
                        found[asp] = []
                    found[asp].append({
                        'sentence': sent,
                        'pred': pred,
                        'probability': prob
                    })
    return found

# -------------------------
# FRONTEND ROUTE
# -------------------------
@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

# -------------------------
# API ROUTE (DEBUG VERSION)
# -------------------------
@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.json
        if data is None:
            return jsonify({"error": True, "message": "Invalid JSON body"}), 400

        text = data.get('text', '')
        if not text:
            return jsonify({"error": True, "message": "Text field is empty"}), 400

        # preprocess
        t = preprocess(text)
        v = tfv.transform([t]).toarray()

        # model prediction
        pred = int(model.predict(v)[0])
        prob = float(model.predict_proba(v).max())

        # aspect-level analysis
        aspects = extract_aspects_using_model(text)

        return jsonify({
            'prediction': pred,
            'probability': prob,
            'aspects': aspects
        })

    except Exception as e:
        print("\n=== Exception in /predict ===")
        traceback.print_exc()
        print("=== END ERROR ===\n")

        return jsonify({
            "error": True,
            "exception_type": type(e).__name__,
            "exception_str": str(e)
        }), 500

# -------------------------
# RUN SERVER
# -------------------------
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
